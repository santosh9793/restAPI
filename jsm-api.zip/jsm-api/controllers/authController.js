const User = require("../models/userModel");
const Otp = require("../models/otpModel");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const transporter = require("../services/email");

module.exports = {
    registerUser: async(req, res) => {
        try{
            //console.log(req.body);
            const {name, email, phone, password} = req.body;
            if(!name || !email || !phone || !password) {
                return res.status(422).json({ success: false, message: 'All feilds are required'});
            }
            const userData = await User.findOne({phone:phone});
            if(userData) {
                return res.status(422).json({ success: false, message: 'Phone already exist'})
            }
            const userIns = new User(req.body);
            const regUser = await userIns.save();
            return res.status(201).json({ success: true, message: 'Register successfully'});
        } catch(error) {
            return res.status(500).json({ success: false, message: 'Could not save the user to DB', error });
        }
    },
    loginUser: async (req, res) => {
        try {
            const {phone, password} = req.body;
            if(!phone || !password) {
                return res.status(422).json({ success: false, message: 'Phone and Password is required'});
            }
            const result = await User.findOne({phone:phone});
            if(result) {
                const isMatch = await bcrypt.compare(password, result.password);
                if(isMatch) {
                    jwt.sign({phone: result.phone}, process.env.ACCESS_TOKEN_SECRET, {expiresIn:'300s'}, (err, token) => {
                       return res.status(200).json({success:true, message: "Login Successfully", result, token})
                    });
                } else {
                    return res.status(422).json({ success: false, message: 'Invalid credentials!' });
                }
            } else {
                return res.status(422).json({ success: false, message: 'Invalid credentials!' });
            }
        } catch(error) {
            return res.status(500).json({ success: false, message: 'Could not login', error });
        }
    },
    changePassword: async (req, res) => {
        try {
            const {id, password, new_password, confirm_password} = req.body;
            const hashPassword = await bcrypt.hash(new_password, 10);
            if(!id || !password || !new_password || !confirm_password) {
                return res.status(422).json({ success: false, message: 'All feilds are required'});
            }
            const result = await User.findById(id);
            //console.log(result);
            if(result) {
                const isMatch = await bcrypt.compare(password, result.password);
                if(isMatch) {
                    const updateUser = await User.findByIdAndUpdate(id, {password:hashPassword});
                    return res.status(200).json({success:true, message: "Updated Successfully"})
                } else {
                    return res.status(422).json({ success: false, message: 'Old Password not match!' });
                }
            } else {
                return res.status(422).json({ success: false, message: 'Invalid Id!' });
            }
        } catch(error) {
            return res.status(500).json({ success: false, message: 'Could not update', error });
        }
    },
    sendMail: async (req, res) => {
        try {
            var mailOptions = {
                from: 'santosh@webclickdigital.com',
                to: 'ssharmagniit@gmail.com',
                subject: 'Santosh Reset Password',
                text: 'Your OTP is:0178'
            };
            
            transporter.sendMail(mailOptions, function(error, info){
                if (error) {
                    return res.status(422).json({success:false,message:"Mail could not send", error})
                } else {
                    return res.status(200).json({success:true,message:"Mail send succeefully"})
                }
            });
        } catch(error) {
            return res.status(500).json({ success: false, message: 'Could not Send', error });
        }
    },
    forgetPassword: async (req, res) => {
        try{
            const email = req.body.email;
            if(!email) {
                return res.status(422).json({success:false, message:"Email is required"})
            }
            const result = await User.findOne({email:email});
            //console.log(result);
            if(result) {
                const currentdate = new Date();
                const expTime = currentdate. getTime() + 300*1000;
                const otpCode = Math.floor((Math.random() * 10000) + 1);
                const otpData = new Otp({
                        email:req.body.email,
                        otp:otpCode,
                        expTime:expTime
                })
                const createOtp = await otpData.save();
                var mailOptions = {
                    from: 'santosh@webclickdigital.com',
                    to: email,
                    subject: 'Reset Password',
                    text: 'Your OTP is:' + otpCode
                };
                
                transporter.sendMail(mailOptions, function(error, info){
                    if (error) {
                        return res.status(422).json({success:false, message:"Mail could not send", error})
                    } else {
                        return res.status(200).json({success:true, message:"Mail send succeefully", createOtp})
                    }
                });
    
            } else {
                return res.status(422).json({success:false, message:"Email id does not exist"})
            }
        } catch (error) {
            return res.status(500).json({success:false, message:"Something went wrong!"})
        }
    },
    resetPassword: async (req, res) => {
        try {
            //console.log(req.body);
            const {email, otp, new_password, confirm_password} = req.body;
            if(!email || !otp || !new_password || !confirm_password) {
                return res.status(422).json({success:false, message:"All feilds are required"});
            }
            const result = await User.findOne({email:email,otp:otp});
            //console.log(result);
            if(result) {
                const currentDate = new Date();
                const currentTime = currentDate.getTime();
                const diff = result.expTime - currentTime;
                if(diff < 0) {
                    return res.status(422).send("Token has been expire!"); 
                }
                const newPassword = await bcrypt.hash(new_password, 10);
                const updateUser = await User.updateOne({email:email}, {password:newPassword});
                return res.status(200).json({success:true, message: "Password Updated Successfully"});
            } else {
                return res.status(422).json({success:false, message: "Email or OTP is not corrent"})
            }
        } catch (error) {
            return res.status(500).json({success:false, message: "Something went wrong"})
        }
    }
}