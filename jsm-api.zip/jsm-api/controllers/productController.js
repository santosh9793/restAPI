const Product = require("../models/productModel");

module.exports = {
    productAdd: async (req, res) => {
        try {
            /* console.log(req.body);
            console.log(req.file); */
            const {title, price, description} = req.body;
            if(!title || !price || !description) {
                return res.status(422).json({success: false, message: "All feilds are required"})
            }
            const proData = await Product.findOne({title:title})
            if(proData) {
                return res.status(422).json({ success: false, message: 'Prodcut title already exist'})
            }
            const productIns = new Product({
                title:req.body.title,
                price:req.body.price,
                description:req.body.description,
                image:req.file.path,
                status:true
            });
            const proCreate = await productIns.save();
            return res.status(201).json({ success: true, message: 'Added successfully', proCreate});
        } catch (errer) {
            return res.status(500).json({success: false, message: "Could not created", errer})
        }
    },
    getAllProducts: async (req, res) => {
        try {
            if(req.query.page && req.query.limit) {
                const productList = await Product.paginate({}, {page: req.query.page, limit: req.query.limit})
                return res.status(200).json({ success: true, message: "Product list", productList });
            } else {
                const productList = await Product.find();
                return res.status(200).json({ success: true, message: "Product list", productList });
            }
        } catch (errer) {
            return res.status(500).json({success: false, message: "Could not fetched", errer})
        }
    },
    findProductById: async (req, res) => {
        const id = req.params.id;
        try {
            const product = await Product.findById(id);
            if (!product) {
                return res.status(422).json({ success: false, message: 'Product does not exist'})
            }
            return res.status(200).json({ success: true, message: "Product list", product });
        } catch (errer) {
            return res.status(500).json({success: false, message: "Could not fetched", errer})
        }
    },
    updateProduct: async (req, res) => {
        try {
            /* console.log(req.body);
            console.log(req.file);
            console.log(req.params); */
            const _id = req.params.id;
            if(!_id) {
                return res.status(422).json({success: false, message: "ID is required"})
            }
            const {title, price, description} = req.body;
            if(!title || !price || !description) {
                return res.status(422).json({success: false, message: "All feilds are required"})
            }
            const options = { new: true };
            const product = await Product.findByIdAndUpdate(_id, {title:req.body.title, price:req.body.price,description:req.body.description,image:req.file.path}, options);
            if (!product) {
                return res.status(422).json({ success: false, message: 'Product does not exist'})
            }
            return res.status(200).json({ success: true, message: "Product updated successfully", product }); 
        } catch (errer) {
            return res.status(500).json({success: false, message: "Could not update", errer})
        }
    }, 
    deleteProduct: async (req, res) => {
        const id = req.params.id;
        try {
          const product = await Product.findByIdAndDelete(id);
          // console.log(product);
          if (!product) {
            return res.status(422).json({ success: false, message: 'Product does not exist'})
          }
          return res.status(200).json({ success: true, message: "Product deleted successfully", product }); 
        } catch (errer) {
            return res.status(500).json({success: false, message: "Could not update", errer})
        }
      }
}