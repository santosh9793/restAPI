const jwt = require("jsonwebtoken");

//get data with jwt authentication 
const authenticate = (req,res,next) => {
    const authorization = req.headers.authorization;
    if(typeof authorization !== 'undefined') {
        const bearer = authorization.split(' ');
        const token = bearer[1];
        jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, function(err, decoded) {
            if(err) {
                res.json({result:err})
            } else {
                next();
            }
        })
    } else {
        res.json({"result":"Token Mismatched"});
    }
}

module.exports = authenticate;