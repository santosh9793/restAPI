const mongoose = require("mongoose");
const otpSchema = mongoose.Schema({
    email:String,
    otp:Number,
    expTime:Number
})

const otp = new mongoose.model("otp", otpSchema);
module.exports = otp;