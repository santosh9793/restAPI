const mongoose = require("mongoose");
const mongoosePaginate = require('mongoose-paginate-v2');
const productSchema = mongoose.Schema({
    title: {
        type: String,
        required: true,
        unique: true
    },
    price: {
        type: Number,
        required: true
    },
    image: String,
    description: String,
    status: Boolean,
    date: {
        type: Date,
        default: Date.now
    }
})

productSchema.plugin(mongoosePaginate)
const products = mongoose.model("product", productSchema);

module.exports = products;