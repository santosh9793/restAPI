const mongoose = require("mongoose");
const bcrypt = require('bcryptjs');

const userSchema = mongoose.Schema({
    name:String,
    email:{
        type: String,
        index: true,
        unique: true,
        required: true
    },
    phone:{
        type: Number,
        index: true,
        minlength: [2, "Min 2"],
        required: true,
        unique: true
    },
    password: String,
    date:{
        type: Date,
        default: Date.now
    }
})

userSchema.pre("save", async function(next) {
    if(this.isModified("password")) {
        this.password = await bcrypt.hash(this.password, 10);
    }
    next();
})

const users = new mongoose.model("users", userSchema);
module.exports =  users;
