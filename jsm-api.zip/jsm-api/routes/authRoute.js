const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");
const upload = require("../middlewares/upload");
const authenticate = require("../middlewares/auth");

router.post("/signup", upload.none(), authController.registerUser);
router.post("/signin", upload.none(), authController.loginUser);
router.post("/changepassword", authenticate, upload.none(), authController.changePassword);
router.get("/sendmail", authController.sendMail);
router.post("/forgetpassword", upload.none(), authController.forgetPassword);
router.post("/resetpassword", upload.none(), authController.resetPassword);

module.exports = router;