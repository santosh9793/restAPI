const express = require("express");
const router = express.Router();

const productController = require("../controllers/productController");
const upload = require("../middlewares/upload");
const authenticate = require("../middlewares/auth");

router.post("/", authenticate, upload.single('image'), productController.productAdd);
router.get("/", authenticate, productController.getAllProducts);
router.get("/:id", authenticate, productController.findProductById);
router.put("/:id", authenticate, upload.single('image'), productController.updateProduct);
router.delete("/:id", authenticate, productController.deleteProduct);

module.exports = router;